<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>오늘의집 헤더 클론</title>
<!-- 프리텐다드 폰트 적용 -->
<link rel="stylesheet" as="style" crossorigin
	href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
<style>
* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: 'Pretendard', sans-serif;
}

a {
	text-decoration: none;
	color: inherit;
}

button {
	border: none;
	background: none;
	cursor: pointer;
	font-family: inherit;
}

/* 컨테이너 최대 너비 지정 */
.header-container {
	max-width: 1136px;
	margin: 0 auto;
	padding: 0 20px;
	width: 100%;
}

/* 1. 최상단 파란 배너 */
.top-event-banner {
	background-color: #1496f4;
	color: white;
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 14px 0;
	font-size: 15px;
	font-weight: 700;
	position: relative;
	cursor: pointer;
	transition: background-color 0.2s;
}

.top-event-banner:hover {
	background-color: #0b80d6;
}

.coupon-icon {
	background: #fff;
	color: #1496f4;
	padding: 2px 6px;
	border-radius: 4px;
	font-size: 11px;
	margin-right: 8px;
	font-weight: 800;
	display: inline-flex;
	align-items: center;
	justify-content: center;
	transform: skewX(-5deg);
}

.btn-close {
	position: absolute;
	right: 20px;
	top: 50%;
	transform: translateY(-50%);
	font-size: 20px;
	font-weight: 300;
	cursor: pointer;
	line-height: 1;
	opacity: 0.8;
}

.btn-close:hover {
	opacity: 1;
}

/* 2. 메인 헤더 영역 */
.header-main-area {
	background: #fff;
	border-bottom: 1px solid #EAEDEF;
	position: sticky;
	top: 0;
	z-index: 100;
}

.header-main-area .header-container {
	display: flex;
	justify-content: space-between;
	align-items: center;
	height: 80px;
}

/* 왼쪽 (로고 + 네비게이션) */
.header-main-left {
	display: flex;
	align-items: center;
	gap: 30px;
}

.header-logo {
	cursor: pointer;
	display: flex;
	align-items: center;
}

.header-logo svg {
	height: 32px;
	width: auto;
}

/* 메인 네비게이션 */
.header-main-nav {
	display: flex;
	gap: 24px;
	font-size: 16px;
	font-weight: 700;
	color: #2F3438;
	white-space: nowrap;
}

.header-main-nav a.active, .header-main-nav a:hover {
	color: #1496f4;
}

.header-main-right {
	display: flex;
	align-items: center;
	gap: 16px;
}

.header-search {
	display: flex;
	align-items: center;
	background-color: #F7F9FA;
	border: 1px solid #DADCE0;
	border-radius: 20px;
	padding: 0 14px;
	width: 240px;
	height: 40px;
	transition: border-color 0.2s, background-color 0.2s;
}

.header-search:focus-within {
	border-color: #1496f4;
	background-color: #fff;
}

.search-icon {
	width: 18px;
	height: 18px;
	color: #828C94;
}

.header-search input {
	border: none;
	background: transparent;
	outline: none;
	width: 100%;
	font-size: 14px;
	margin-left: 6px;
	color: #2F3438;
	font-weight: 500;
}

.header-search input::placeholder {
	color: #9E9E9E;
	font-weight: 400;
}

.header-icon-btn {
	background: none;
	border: none;
	cursor: pointer;
	color: #2F3438;
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 4px;
	transition: color 0.2s;
}

.header-icon-btn svg {
	width: 24px;
	height: 24px;
}

.header-icon-btn:hover {
	color: #1496f4;
}

.header-auth-nav {
	display: flex;
	align-items: center;
	gap: 12px;
	font-size: 14px;
	font-weight: 400;
	color: #424242;
	white-space: nowrap;
}

.header-auth-nav a {
	position: relative;
	padding: 0 2px;
	transition: color 0.2s;
}

.header-auth-nav a:not(:last-child)::after {
	content: "";
	position: absolute;
	right: -8px;
	top: 50%;
	transform: translateY(-50%);
	width: 1px;
	height: 12px;
	background-color: #EAEDEF;
}

.header-auth-nav a:hover {
	color: #1496f4;
}

/* 로그인 후 프로필 드롭다운 영역 */
.header-profile-wrap {
	position: relative;
}

.header-profile-btn {
	width: 32px;
	height: 32px;
	border-radius: 50%;
	background-color: #E0E4E8;
	border: none;
	cursor: pointer;
	display: flex;
	align-items: center;
	justify-content: center;
	color: #828C94;
	overflow: hidden;
	transition: opacity 0.2s;
}

.header-profile-btn:hover {
	opacity: 0.8;
}

.header-profile-btn svg {
	width: 28px;
	height: 28px;
}

.profile-dropdown-menu {
	display: none;
	position: absolute;
	right: 0;
	top: 45px;
	width: 180px;
	background: #fff;
	border: 1px solid #EAEDEF;
	border-radius: 8px;
	box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
	padding: 8px 0;
	z-index: 200;
}

.profile-dropdown-menu.show {
	display: block;
}

.profile-dropdown-menu a {
	display: block;
	padding: 10px 16px;
	font-size: 14px;
	color: #2F3438;
	transition: background 0.15s;
}

.profile-dropdown-menu a:hover {
	background-color: #F7F9FA;
	color: #1496f4;
}

.profile-dropdown-menu hr {
	border: none;
	border-top: 1px solid #EAEDEF;
	margin: 6px 0;
}

/* 글쓰기 버튼 */
.header-btn-write {
	background-color: #1496f4;
	color: white;
	padding: 0 14px;
	height: 40px;
	border-radius: 6px;
	font-size: 14px;
	font-weight: 700;
	cursor: pointer;
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 6px;
	white-space: nowrap;
	transition: background-color 0.2s;
}

.header-btn-write:hover {
	background-color: #0b80d6;
}

.header-btn-write svg {
	width: 12px;
	height: 12px;
	stroke: white;
	stroke-width: 2.5;
	stroke-linecap: round;
	stroke-linejoin: round;
}
</style>
</head>
<body>

	<header>
		<!-- 1. 최상단 배너 -->
		<div class="top-event-banner">
			<span class="coupon-icon">2만원</span> <span>첫 구매라면 누구나 최대 2만원
				할인! &gt;</span> <span class="btn-close">✕</span>
		</div>

		<!-- 2. 메인 헤더 -->
		<div class="header-main-area">
			<div class="header-container">

				<!-- 왼쪽 영역 -->
				<div class="header-main-left">
					<a href="${pageContext.request.contextPath}/main.htm" class="header-logo"> 
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 481 136">
                            <path fill="#111" d="M459.317 41.715H443.04c.134 2.783 1.008 5.303 4.532 8.903s9.133 7.32 15.825 11.457l-6.497 10.51c-6.865-4.243-13.264-8.501-17.985-13.322-.983-1.004-1.92-1.884-2.791-2.98a30 30 0 0 1-2.791 3.323c-4.721 4.82-11.12 9.251-17.985 13.494l-6.497-10.51c6.692-4.137 12.3-8.03 15.825-11.63 3.525-3.599 4.398-6.462 4.532-9.245h-16.277V30.73h46.386zM202.316 29.28c17.481 0 26.613 11.252 26.613 24.263v1.758c0 11.355-6.9 21.37-20.325 23.736V91.98h32.522v10.983h-78.087V91.981h32.522V79.04c-13.441-2.358-20.349-12.378-20.349-23.74v-1.758c0-13.01 9.132-24.263 26.613-24.263zm-.245 10.64c-9.429 0-14.073 6.716-14.073 13.79v1.424c0 7.074 4.714 13.79 14.073 13.79s14.073-6.716 14.073-13.79V53.71c0-7.074-4.645-13.79-14.073-13.79m197.014 73.188h-13.043V94.844c-3.364.484-9.354 1.26-18.175 2.086-14.622 1.372-40.328 1.125-40.328 1.125l-.209-11.819s25.813.169 39.599-.952c9.613-.782 16.079-1.739 19.113-2.247V26.154h13.043zM353.77 30.996c14.752 0 22.408 9.841 22.408 21.089v1.757c0 11.247-7.728 21.088-22.408 21.088l-.491-.005c-14.68 0-22.408-9.836-22.408-21.083v-1.757c0-11.248 7.656-21.089 22.408-21.089zm-.245 10.726c-6.727 0-10.126 5.376-10.126 10.706v1.07c0 5.897 3.399 10.684 10.127 10.706 6.662.022 10.124-4.82 10.124-10.706v-1.07c0-5.33-3.462-10.706-10.125-10.706M268.667 43.4h44.696v10.813h-57.739V26.85h13.043zm-23.778 26.215h78.086V58.803h-78.086z" />
                            <path fill="#111" d="M479.999 99.939c-.011 10.413-2.221 12.533-12.761 12.54-11.69.007-18.439.011-30.148 0-10.245-.01-12.616-2.046-12.697-11.824-.077-9.232.002-25.554.002-25.567h13.043v9.153h29.69V26.155H480s.03 45.359-.001 73.784m-42.561 1.728h29.69V94.71h-29.69zM313.005 74.209l.004 24.48h-45.043v4.739h46.979v10.297h-47.151c-10.653 0-12.846-2.098-12.871-12.595-.01-4.223 0-12.396 0-12.396h45.039v-4.4h-44.691V74.208z" />
                            <path fill="#00a1ff" d="M75.001 1.243a20.72 20.72 0 0 0-14.136 0c-8.591 3.093-36.22 21.208-51.007 36.46C1.88 45.928 0 51.618 0 61.48v5.078c.126 15.644.914 34.269 3.675 43.324 4.773 15.652 11.949 25.984 57.295 25.984h13.926c45.345 0 52.521-10.332 57.295-25.984 2.761-9.055 3.549-27.68 3.675-43.325v-5.078c0-9.861-1.882-15.551-9.858-23.777-14.789-15.25-42.414-33.366-51.007-36.459" />
                        </svg>
					</a>
					<nav class="header-main-nav">
						<a href="#">집구경</a> <a href="/main.htm" class="active">쇼핑</a> <a href="#">인테리어/생활</a>
					</nav>
				</div>

				<!-- 오른쪽 영역 -->
				<div class="header-main-right">

					<!-- 둥근 통합 검색창 -->
					<form action="${pageContext.request.contextPath}/search.htm"
						method="GET" class="header-search">
						<svg class="search-icon" fill="none" stroke="currentColor"
							viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        					<path stroke-linecap="round" stroke-linejoin="round"
								stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
    					</svg>
						<input type="text" name="keyword" placeholder="통합검색">
					</form>

					<c:choose>
						<c:when test="${not empty sessionScope.authUser or not empty sessionScope.sellerAuth}">
							<!-- 스크랩 북마크 아이콘 -->
							<button class="header-icon-btn" title="스크랩북">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
								</svg>
							</button>

							<!-- 알림 아이콘 -->
							<button class="header-icon-btn" title="알림">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
									<path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
								</svg>
							</button>

							<!-- 장바구니 아이콘 -->
							<button class="header-icon-btn" title="장바구니">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<circle cx="9" cy="21" r="1"></circle>
									<circle cx="20" cy="21" r="1"></circle>
									<path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
								</svg>
							</button>

							<div class="header-profile-wrap">
								<button class="header-profile-btn" id="profileToggleBtn" title="마이페이지">
									<svg viewBox="0 0 24 24" fill="currentColor">
										<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
									</svg>
								</button>
								
								<div class="profile-dropdown-menu" id="profileDropdown">
									<a href="${pageContext.request.contextPath}/member/myPage.htm">마이페이지</a>
									<a href="#">나의 쇼핑</a>
									<a href="#">시공/생활 상담내역</a>
									<a href="#">이벤트</a>
									<hr>
									<a href="${pageContext.request.contextPath}/logout.htm">로그아웃</a>
								</div>
							</div>
						</c:when>
						<c:otherwise>
							<!-- 장바구니 아이콘 -->
							<button class="header-icon-btn" title="장바구니">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<circle cx="9" cy="21" r="1"></circle>
									<circle cx="20" cy="21" r="1"></circle>
									<path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
								</svg>
							</button>

							<div class="header-auth-nav">
								<a href="${pageContext.request.contextPath}/login.htm">로그인</a>
								<a href="${pageContext.request.contextPath}/signup.htm">회원가입</a>
								<a href="#">고객센터</a>
							</div>
						</c:otherwise>
					</c:choose>

					<!-- 글쓰기 버튼 -->
					<button class="header-btn-write">
						글쓰기 
						<svg viewBox="0 0 24 24" fill="none">
							<path d="M6 9l6 6 6-6"></path>
						</svg>
					</button>

				</div>
			</div>
		</div>
	</header>

	<!-- 프로필 드롭다운 토글 스크립트 -->
	<script>	
		const profileBtn = document.getElementById('profileToggleBtn');
		const profileDropdown = document.getElementById('profileDropdown');

		if (profileBtn && profileDropdown) {
			profileBtn.addEventListener('click', function(e) {
				e.stopPropagation();
				profileDropdown.classList.toggle('show');
			});

			window.addEventListener('click', function() {
				if (profileDropdown.classList.contains('show')) {
					profileDropdown.classList.remove('show');
				}
			});
		}
	</script>
</body>
</html>