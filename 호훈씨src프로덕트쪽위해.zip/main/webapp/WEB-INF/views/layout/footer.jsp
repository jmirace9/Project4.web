<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<style>
    /* =========================
   Footer 전체
========================= */

    .footer-wrapper {
        width: 100%;
        background-color: #f7f9fa;
        padding: 38px 0 42px;
        border-top: 1px solid #eaecef;
        box-sizing: border-box;
    }

    .footer-container {
        width: 50%;
        padding: 0 20px;
        box-sizing: border-box;
        margin : 0 auto;
        display: grid;
        grid-template-columns: 280px 1fr 1.35fr;
        gap: 40px;
    }


    /* =========================
       고객센터
    ========================= */

    .footer-cs {
        padding-right: 24px;
    }

    .footer-cs .cs-title {
        display: block;
        margin-bottom: 16px;

        font-size: 15px;
        font-weight: 700;
        color: #2f3438;
        text-decoration: none;
    }

    .cs-box {
        width: 100%;
        height: 62px;
        box-sizing: border-box;

        background: #fff;
        border: 1px solid #e5e7e9;
        border-radius: 7px;

        padding: 11px 14px;

        display: flex;
        justify-content: space-between;
        align-items: center;

        margin-bottom: 8px;
    }

    .cs-box-left {
        display: flex;
        flex-direction: column;
        gap: 3px;
    }

    .cs-box-title {
        font-size: 14px;
        font-weight: 700;
        color: #2f3438;
    }

    .cs-box-desc {
        font-size: 11px;
        color: #828c94;
        line-height: 1.4;
    }

    .cs-box-arrow {
        color: #aeb4b8;
        font-size: 16px;
    }


    /* =========================
       중앙 링크 메뉴
    ========================= */

    .footer-links {
        display: grid;
        grid-template-columns: 1fr 1fr;

        padding: 4px 24px;

        border-left: 1px solid #e5e7e9;
        border-right: 1px solid #e5e7e9;
    }

    .footer-links ul {
        list-style: none;
        padding: 0;
        margin: 0;

        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .footer-links li {
        font-size: 12px;
        color: #59636b;
        cursor: pointer;
        white-space: nowrap;
    }

    .footer-links li.bold {
        font-weight: 700;
        color: #2f3438;
    }

    .footer-links li:hover {
        text-decoration: underline;
    }


    /* =========================
       오른쪽 회사 정보
    ========================= */

    .footer-info {
        padding-left: 0;

        font-size: 11px;
        color: #828c94;
        line-height: 1.6;
    }

    .info-text {
        margin-bottom: 13px;
    }

    .footer-info a {
        color: #59636b;
    }


    /* =========================
       인증 마크
    ========================= */

    .cert-marks {
        display: flex;
        gap: 6px;
        margin: 13px 0;
    }

    .cert-box {
        height: 43px;
        min-width: 72px;

        box-sizing: border-box;

        border: 1px solid #e1e5e7;
        background: #fff;

        padding: 5px 8px;

        border-radius: 2px;

        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;

        font-size: 8px;
        color: #8b949b;
    }

    .cert-box img {
        height: 20px;
    }


    /* =========================
       안내 문구
    ========================= */

    .disclaimer {
        font-size: 10px;
        color: #9ba3a8;
        line-height: 1.5;

        margin-bottom: 13px;
    }


    /* =========================
       SNS
    ========================= */

    .footer-sns {
        display: flex;
        gap: 9px;
        margin-bottom: 13px;
    }

    .sns-icon {
        width: 25px;
        height: 25px;

        border-radius: 50%;
        background: #e7eaec;

        display: flex;
        justify-content: center;
        align-items: center;

        color: #7d878e;
        font-size: 12px;
    }

    .sns-icon:hover {
        background: #dce0e3;
    }


    /* =========================
       저작권
    ========================= */

    .copyright {
        font-size: 10px;
        color: #9ba3a8;
    }
</style>

<footer class="footer-wrapper">
    <div class="footer-container">

        <!-- 좌측: 고객센터 -->
        <div class="footer-cs">
            <a href="#" class="cs-title">고객센터 ></a>

            <div class="cs-box">
                <div class="cs-box-left">
                    <span class="cs-box-title">1:1 문의</span>
                    <span class="cs-box-desc">24시간 접수 · 평일 09:00-18:00 답변</span>
                </div>
                <span class="cs-box-arrow">></span>
            </div>

            <div class="cs-box">
                <div class="cs-box-left">
                    <span class="cs-box-title">채팅 상담</span>
                    <span class="cs-box-desc">평일 09:00-18:00</span>
                </div>
                <span class="cs-box-arrow">></span>
            </div>

            <div class="cs-box">
                <div class="cs-box-left">
                    <span class="cs-box-title">1670-0876</span>
                    <span class="cs-box-desc">평일 09:00-18:00 · 일요일 : 휴무<br>토·공휴일 : 원하는날도착 주문건 상담</span>
                </div>
                <span class="cs-box-arrow">></span>
            </div>
        </div>

        <!-- 중앙: 링크 메뉴 -->
        <div class="footer-links">
            <ul>
                <li>회사소개</li>
                <li>채용정보</li>
                <li>이용약관</li>
                <li class="bold">개인정보 처리방침</li>
                <li>공지사항</li>
                <li>권리보호센터</li>
            </ul>
            <ul>
                <li>입점신청</li>
                <li>제휴/광고 문의</li>
                <li>시공파트너 안내</li>
                <li class="bold">파트너 개인정보 처리방침</li>
                <li>상품광고 소개</li>
                <li>결제대행 위탁사</li>
            </ul>
        </div>

        <!-- 우측: 정보 및 인증 -->
        <div class="footer-info">
            <div class="info-text">
                (주)버킷플레이스 | 대표이사 이승재 | 서울 서초구 서초대로74길 4 삼성생명서초타워 25층, 27층<br>
                contact@bucketplace.net | 사업자등록번호 119-86-91245 <a href="#"
                                                                  style="text-decoration:underline; font-weight:700;">사업자정보확인</a><br>
                통신판매업신고번호 제2018-서울서초-0580호
            </div>

            <div class="info-text" style="color:#2F3438;">
                고객님이 현금결제한 금액에 대해 우리은행과 채무지급보증 계약을 체결하여 안전거래를 보장하고 있습니다. <a href="#"
                                                                            style="text-decoration:underline; font-weight:700;">서비스가입사실확인</a>
            </div>

            <!-- 3개 인증마크 레이아웃 -->
            <div class="cert-marks">
                <div class="cert-box">
                    <span style="font-size:16px; font-weight:900; color:#2F3438;">ISMS</span>
                    <span>오늘의집 서비스 운영<br>2024. 09. 08 ~ 2027. 09. 07</span>
                </div>
                <div class="cert-box">
                    <span style="font-size:16px; font-weight:900; color:#00A6EA;">DNV</span>
                </div>
                <div class="cert-box">
                    <span style="font-size:16px; font-weight:900; color:#1877F2;">PCR</span>
                </div>
            </div>

            <div class="disclaimer">
                (주)버킷플레이스는 통신판매중개자로 거래 당사자가 아니므로, 판매자가 등록한 상품정보 및 거래 등에 대해 책임을 지지 않습니다. 단, (주)버킷플레이스가 판매자로 등록 판매한 상품은
                판매자로서 책임을 부담합니다.
            </div>

            <div class="footer-sns">
                <div class="sns-icon">Y</div>
                <div class="sns-icon">I</div>
                <div class="sns-icon">F</div>
                <div class="sns-icon">K</div>
            </div>

            <div class="copyright">
                Copyright 2014. bucketplace, Co., Ltd. All rights reserved.
            </div>
        </div>

    </div>
</footer>
</body>
</html>