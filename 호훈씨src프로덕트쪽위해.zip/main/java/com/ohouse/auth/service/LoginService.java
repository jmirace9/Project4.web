package com.ohouse.auth.service;

import com.ohouse.member.domain.MemberDTO;
import com.ohouse.member.persistence.MemberDAO;
import com.util.ConnectionProvider;

import javax.naming.NamingException;
import java.lang.reflect.Member;
import java.sql.Connection;
import java.sql.SQLException;

public class LoginService {

	private MemberDAO memberDao = new MemberDAO();

	public MemberDTO login(MemberDTO memberDTO) {

		try (Connection conn = ConnectionProvider.getConnection()) {

			MemberDTO member = memberDao.loginMember(conn,memberDTO);
			
			if (member == null) {
				throw new LoginFailException();
			}
			if (!member.matchPassword(memberDTO.getPassword())) {
				throw new LoginFailException();
			}
			return member;
			
		} catch (SQLException | NamingException e) {
			throw new RuntimeException(e);
		}
	}
}
