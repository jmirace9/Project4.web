package com.ohouse.auth.service;

public class LoginFailException extends RuntimeException {

}
