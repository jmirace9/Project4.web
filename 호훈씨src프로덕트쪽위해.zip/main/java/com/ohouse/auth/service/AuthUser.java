package com.ohouse.auth.service;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class AuthUser {

	private String id;
	private String password;

}
