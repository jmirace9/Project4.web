package com.ohouse.auth.command;

import com.ohouse.auth.service.AuthUser;
import com.ohouse.auth.service.LoginFailException;
import com.ohouse.auth.service.LoginService;
import com.ohouse.common.CommandHandler;
import com.ohouse.member.domain.MemberDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;

public class LoginHandler implements CommandHandler {

    private static final String FORM_VIEW = "/WEB-INF/views/member/login.jsp";
    private LoginService loginService = new LoginService();

    @Override
    public String process(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
        if (req.getMethod().equalsIgnoreCase("GET")) {
            return processForm(req, res);
        } else if (req.getMethod().equalsIgnoreCase("POST")) {
            return processSubmit(req, res);
        } else {
            res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return null;
        }
    }

    private String processForm(HttpServletRequest req, HttpServletResponse res) {
        return FORM_VIEW;
    }

    private String processSubmit(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
        String id = trim(req.getParameter("id"));
        String password = trim(req.getParameter("password"));

        MemberDTO dto = new MemberDTO();
        dto.setId(id);
        dto.setPassword(password);

        Map<String, Boolean> errors = new HashMap<>();
        req.setAttribute("errors", errors);

        if (id == null || id.isEmpty())
            errors.put("id", Boolean.TRUE);
        if (password == null || password.isEmpty())
            errors.put("password", Boolean.TRUE);

        if (!errors.isEmpty()) {
            return FORM_VIEW;
        }

        try {

            MemberDTO adto = loginService.login(dto);
            // 세션 저장.
            HttpSession session = req.getSession();

            session.setAttribute("adto", adto);

            // 외부 URL 저장 방지
            String contextPath = req.getContextPath();

            String location;

            // 회원과 판매자 경로 구분
			/*if ( "Seller".equals(adto.getRole()) ) {
				location = contextPath + "/seller/main.htm";
			} else {
				location = contextPath + "/main.htm";
			}*/
			String referer = (String) session.getAttribute("referer");


            if (referer != null
                    && referer.startsWith(contextPath + "/")) {
                location = referer;
                session.removeAttribute("referer");
            } else {
                location = contextPath + "/main.htm";
            }
            res.sendRedirect(location);
            return null;

        } catch (LoginFailException e) {
            errors.put("idOrPwNotMatch", Boolean.TRUE);
            return FORM_VIEW;
        }
    }

    private String trim(String str) {
        return str == null ? null : str.trim();
    }
}
