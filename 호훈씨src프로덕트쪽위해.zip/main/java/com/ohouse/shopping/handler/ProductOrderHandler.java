package com.ohouse.shopping.handler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ohouse.common.CommandHandler;
import com.ohouse.shopping.domain.OrderItemDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

public class ProductOrderHandler implements CommandHandler {
    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // JSON -> List
        List<OrderItemDTO> orderItems =
                mapper.readValue(
                        request.getReader(),
                        new TypeReference<List<OrderItemDTO>>() {
                        }
                );

        // 주문 정보 세션에 저장
        request.getSession().setAttribute("orderItems", orderItems);
        // 주문 페이지로 이동
        return null;
    }
}
