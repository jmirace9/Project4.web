package com.ohouse.shopping.handler;

import com.ohouse.common.CommandHandler;
import com.ohouse.shopping.domain.ProductDTO;
import com.ohouse.shopping.service.ProductService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

public class shoppingHomeHandler implements CommandHandler {
    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

        ProductService psvc = new ProductService();
        List<ProductDTO> pdto = psvc.getProductList();

        request.setAttribute("pdto", pdto);

        return "/WEB-INF/views/shopping/shoppinghome.jsp";
    }
}
