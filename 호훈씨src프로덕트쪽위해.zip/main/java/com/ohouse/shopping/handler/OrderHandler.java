package com.ohouse.shopping.handler;

import com.ohouse.common.CommandHandler;
import com.ohouse.shopping.domain.OrderItemDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

public class OrderHandler implements CommandHandler {
    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<OrderItemDTO> orderdto = (List<OrderItemDTO>) request.getSession().getAttribute("orderItems");
        request.setAttribute("orderdto", orderdto);
        return "/WEB-INF/views/shopping/order.jsp";
    }
}
