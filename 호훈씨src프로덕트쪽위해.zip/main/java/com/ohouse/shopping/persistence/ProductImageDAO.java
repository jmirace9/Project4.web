package com.ohouse.shopping.persistence;

import com.ohouse.shopping.domain.OptionDTO;
import com.ohouse.shopping.domain.ProductImageDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductImageDAO {

    public List<ProductImageDTO> viewImage(Connection conn, long product_id) throws SQLException {

        String sql = """
                
                   select image_url,sort_order
                from product_image
                where product_id = ?
                   order by sort_order
                """;
        List<ProductImageDTO> list = null;
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, product_id);

            try (ResultSet rs = pstmt.executeQuery()) {
                list = new ArrayList<>();
                while(rs.next()) {

                    ProductImageDTO dto = new ProductImageDTO();


                    dto.setImage_url(rs.getString("IMAGE_URL"));

                    dto.setSort_order(rs.getInt("SORT_ORDER"));

                    list.add(dto);

                }
            }
        }

        return list;
    }
}
