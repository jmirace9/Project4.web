package com.ohouse.shopping.persistence;

import com.ohouse.shopping.domain.ProductDTO;
import com.util.ConnectionProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public ProductDTO viewProduct(Connection conn, long product_id) throws SQLException {

        String sql = """
                SELECT *
                FROM product
                WHERE product_id = ?
                """;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, product_id);

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return new ProductDTO(
                            rs.getLong("brand_id"),
                            rs.getString("product_name"),
                            rs.getLong("original_price"),
                            rs.getLong("price"),
                            rs.getLong("category_id"),
                            rs.getDouble("discount_rate")
                    );
                }
            }
        }

        return null;
    }

    // 전체 상품 보기
    public List<ProductDTO> allviewProduct(Connection conn) throws SQLException {
        String sql = """
                        SELECT * FROM PRODUCT
                        ORDER BY PRODUCT_ID
                """;
        ProductDTO pdto = null;
        List<ProductDTO> list = null;
        try (
                PreparedStatement pstmt = conn.prepareStatement(sql);
                ResultSet rs = pstmt.executeQuery();
        ) {
            while (rs.next()) {
                list = new ArrayList<>();
                pdto = new ProductDTO(
                        rs.getLong("brand_id"),
                        rs.getString("product_name"),
                        rs.getLong("original_price"),
                        rs.getLong("price"),
                        rs.getLong("category_id"),
                        rs.getDouble("discount_rate")
                  );
                list.add(pdto);
            }
        }
        return list;
    }
}
