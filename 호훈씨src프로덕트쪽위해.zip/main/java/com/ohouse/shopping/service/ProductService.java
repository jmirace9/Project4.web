package com.ohouse.shopping.service;

import com.ohouse.shopping.domain.*;
import com.ohouse.shopping.persistence.CategoryDAO;
import com.ohouse.shopping.persistence.OptionDAO;
import com.ohouse.shopping.persistence.ProductDAO;
import com.ohouse.shopping.persistence.ProductImageDAO;
import com.ohouse.shopping.persistence.ProductOptionDAO;
import com.util.ConnectionProvider;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ProductService {

    private ProductDAO productDAO = new ProductDAO();
    private ProductImageDAO imageDAO = new ProductImageDAO();
    private OptionDAO optionDAO = new OptionDAO();
    private CategoryDAO categoryDAO = new CategoryDAO();
    private ProductOptionDAO productOptionDAO = new ProductOptionDAO();

    // 상품 상세 조회
    public ProductDetailDTO getProductDetail(long product_id) throws Exception {

        try (Connection conn = ConnectionProvider.getConnection()) {

            ProductDTO product =
                    productDAO.viewProduct(conn, product_id);

            List<ProductImageDTO> images =
                    imageDAO.viewImage(conn, product_id);

            List<OptionDTO> options =
                    optionDAO.viewOption(conn, product_id);

            List<CategoryDTO> categories =
                    categoryDAO.viewCategory(conn, product_id);

            ProductDetailDTO detail = new ProductDetailDTO();

            detail.setProductDTO(product);
            detail.setImageDTOList(images);
            detail.setOptionDTOList(options);
            detail.setCategoryDTOList(categories);

            return detail;
        }
    }

    // 선택한 옵션 조합의 상품 옵션 조회
    public ProductOptionDTO getProductOption(
            long product_id,
            List<Long> optionValueIds
    ) throws Exception {

        try (Connection conn = ConnectionProvider.getConnection()) {

            return productOptionDAO.findProductOption(
                    conn,
                    product_id,
                    optionValueIds
            );
        }
    }

    // 쇼핑홈에서 전체 상품 가져오기
    public List<ProductDTO> getProductList() throws Exception {
        try (Connection conn = ConnectionProvider.getConnection()) {

            List<ProductDTO> pdto = productDAO.allviewProduct(conn);
            return pdto;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}