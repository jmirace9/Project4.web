package com.ohouse.shopping.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ProductDetailDTO {

    private ProductDTO productDTO;
    private List<ProductImageDTO> imageDTOList;
    private List<OptionDTO> optionDTOList;
    private List<CategoryDTO> categoryDTOList;
}
