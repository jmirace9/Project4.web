package com.ohouse.shopping.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ProductDTO {

        private long brand_id;
        private String product_name;
        private long original_price;
        private long price;
        private long category_id;
        private double discount_rate;

}
