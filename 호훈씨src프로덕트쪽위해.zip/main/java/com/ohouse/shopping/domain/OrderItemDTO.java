package com.ohouse.shopping.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
public class OrderItemDTO {
    private String product_name;
    private long product_option_id;
    private long product_id;
    private String sku;
    private int price;
    private int quantity;

    private List<OrderOptionDTO> options;

}
