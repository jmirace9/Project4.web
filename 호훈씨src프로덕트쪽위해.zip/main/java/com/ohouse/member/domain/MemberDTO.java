package com.ohouse.member.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor

public class MemberDTO {


    private String id;
    private String name;
    private String password;


    public MemberDTO(String id, String password, String name) {
        this.id = id;
        this.password = password;
        this.name = name;
    }

    public MemberDTO(String id, String password) {
        this.id = id;
        this.password = password;
    }

    public boolean matchPassword(String pwd) {
        return password.equals(pwd);
    }


}
