package com.ohouse.member.persistence;

import com.ohouse.member.domain.MemberDTO;
import com.ohouse.member.service.ADDCheck;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Date;
import java.util.List;

public class MemberDAO {

    public int registerMember(Connection conn, MemberDTO memberDTO) throws SQLException {

        String sql = """
                    INSERT INTO MEMBER(ID,NAME,PASSWORD,REG_DATE,RANK,ROLE) 
                    VALUES(?,?,?,SYSDATE,'NORMAL','USER')                   
                """;
        int rowcount = 0;
        try (
                PreparedStatement pstmt = conn.prepareStatement(sql);
        ) {
            pstmt.setString(1, memberDTO.getId());
            pstmt.setString(2, memberDTO.getName());
            pstmt.setString(3, memberDTO.getPassword());

            rowcount = pstmt.executeUpdate();
        }
        return rowcount;
    }

    public MemberDTO loginMember(Connection conn, MemberDTO dto) throws SQLException {
        String sql = """
                    SELECT ID,NAME
                    FROM MEMBER
                    WHERE ID = ? AND PASSWORD = ?
                """;

        try (PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1,dto.getId());
            pstmt.setString(2, dto.getPassword());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {

                dto.setId(rs.getString("ID"));
                dto.setName(rs.getString("NAME"));

                return dto;
            }
        }

        return null;
    }

}
