package com.ohouse.member.handler;

import com.ohouse.common.CommandHandler;
import com.ohouse.member.domain.MemberDTO;
import com.ohouse.member.service.ADDCheck;
import com.ohouse.member.service.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.HashMap;
import java.util.Map;


public class MemberAddHandler implements CommandHandler {

    /*   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
           if (request.getMethod().equals("GET")) {
               return "/WEB-INF/views/member/addmember.jsp";
           } else if (request.getMethod().equals("POST")) {

               MemberDTO mDto = new MemberDTO(
                       request.getParameter("id"),
                       request.getParameter("name"),
                       request.getParameter("password")

               );

               MemberService mSvc = new MemberService();
               int result = mSvc.addMember(mDto);
               if (result > 0) {
                   request.setAttribute("memberName", mDto.getName());
                   return "/WEB-INF/views/member/addMemberSuccess.jsp";
               }
           }*/
    private static final String FORM_VIEW = "/WEB-INF/views/member/addmember.jsp";
    MemberService memberService = new MemberService();

    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (request.getMethod().equalsIgnoreCase("GET")) {
            return processForm(request, response);
        } else if (request.getMethod().equalsIgnoreCase("POST")) {
            return processSubmit(request, response);
        } else {
            response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return null;
        }
    }

    private String processForm(HttpServletRequest req, HttpServletResponse res) {
        return FORM_VIEW;
    }

    private String processSubmit(HttpServletRequest req, HttpServletResponse res) {
        ADDCheck addCheck = new ADDCheck();

        addCheck.setId(req.getParameter("id"));
        addCheck.setName(req.getParameter("name"));
        addCheck.setPassword(req.getParameter("password"));
        addCheck.setConfirmPassword(req.getParameter("confirmPassword"));

        Map<String, Boolean> errors = new HashMap<>();
        req.setAttribute("errors", errors);

        addCheck.validate(errors);

        if (!errors.isEmpty()) {
            return FORM_VIEW;
        }
        System.out.println("ADDCheck id = " + addCheck.getId());
        MemberDTO memberDTO = new MemberDTO(
                addCheck.getId(),
                addCheck.getPassword(),
                addCheck.getName()
        );

        System.out.println("DTO id = " + memberDTO.getId());
        try {
            memberService.addMember(memberDTO);
              req.setAttribute("memberName", memberDTO.getName());
            return "/WEB-INF/views/member/addmemberok.jsp";
        } catch (Exception e) {
            errors.put("duplicateId", Boolean.TRUE);
            return FORM_VIEW;
        }
    }


}



