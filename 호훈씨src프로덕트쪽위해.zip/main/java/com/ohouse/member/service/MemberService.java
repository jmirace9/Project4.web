package com.ohouse.member.service;

import com.ohouse.member.domain.MemberDTO;
import com.ohouse.member.persistence.MemberDAO;
import com.util.ConnectionProvider;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class MemberService {

    MemberDAO memberDAO = new MemberDAO();

    public int addMember(MemberDTO memberDTO) {


        try (Connection conn = ConnectionProvider.getConnection()) {

            return memberDAO.registerMember(conn, memberDTO);

        } catch (SQLException | NamingException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
