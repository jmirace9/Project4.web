package com.ohouse.service;

public class StoreService {
}
